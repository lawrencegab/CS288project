#!/bin/sh



p=60





for(( i=0 ; i < $p ; i++));
do


	cdate=`date +%Y_%m_%d_%H_%M_%S`
    wget -O $cdate.html http://online.wsj.com/mdc/public/page/2_3021-activnyse-actives.html
    java -jar tagsoup-1.2.1.jar --files $cdate.html
    #python hw9.py ${cdate}.html
    
    
    sleep 60


done




#wget -O $cdate.html google.com
#watch -n60 `wget -O $cdate.html google.com`



